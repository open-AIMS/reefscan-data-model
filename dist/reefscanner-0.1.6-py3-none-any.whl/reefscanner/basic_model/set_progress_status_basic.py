def set_progress_status_basic(function, value):
    print(f"{function} {value}")
